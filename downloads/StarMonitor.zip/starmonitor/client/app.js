const $=s=>document.querySelector(s);
let token='',pc=null,ws=null,statT=null;
if('serviceWorker' in navigator&&window.isSecureContext)navigator.serviceWorker.register('sw.js').catch(()=>{});
$('#go').onclick=connect;
$('#pin').addEventListener('keydown',e=>{if(e.key==='Enter')connect()});

async function connect(){
 const msg=$('#msg');msg.textContent='Conectando...';
 try{
  const r=await fetch('api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pin:$('#pin').value.trim()})});
  const j=await r.json();if(!r.ok){msg.textContent=j.error||'Erro';return}
  token=j.token;await startRtc();openWs();
  $('#login').hidden=true;$('#view').hidden=false;fullscreen();
 }catch(e){msg.textContent='Falha: '+e.message}
}
async function startRtc(){
 pc=new RTCPeerConnection({iceServers:[]}); // sem STUN/TURN: só rede local
 pc.addTransceiver('video',{direction:'recvonly'});
 pc.ontrack=e=>{const v=$('#v');v.srcObject=e.streams[0]||new MediaStream([e.track]);v.play().catch(()=>{});
  pc.getReceivers().forEach(r=>{try{r.jitterBufferTarget=0}catch(x){}try{r.playoutDelayHint=0}catch(x){}})};
 pc.onconnectionstatechange=()=>{if(['failed','closed'].includes(pc.connectionState))location.reload()};
 await pc.setLocalDescription(await pc.createOffer());
 await new Promise(r=>{if(pc.iceGatheringState==='complete')return r();
  pc.onicegatheringstatechange=()=>{if(pc.iceGatheringState==='complete')r()};setTimeout(r,2000)});
 const res=await fetch('api/offer',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},
  body:JSON.stringify({sdp:pc.localDescription.sdp,type:pc.localDescription.type})});
 if(!res.ok)throw new Error('Oferta recusada ('+res.status+')');
 await pc.setRemoteDescription(await res.json());
}
function openWs(){
 ws=new WebSocket((location.protocol==='https:'?'wss://':'ws://')+location.host+'/ws?t='+encodeURIComponent(token));
 ws.onclose=()=>location.reload();
}
const send=o=>{if(ws&&ws.readyState===1)ws.send(JSON.stringify(o))};
function fullscreen(){document.documentElement.requestFullscreen?.().then(()=>screen.orientation?.lock?.('landscape').catch(()=>{})).catch(()=>{})}

/* Toque -> mouse na segunda tela */
const v=$('#v');let st=null,lp=null,pend=null,raf=0;
const pct=(cx,cy)=>{const r=v.getBoundingClientRect(),vw=v.videoWidth||1,vh=v.videoHeight||1,k=Math.min(r.width/vw,r.height/vh),w=vw*k,h=vh*k,l=r.left+(r.width-w)/2,t=r.top+(r.height-h)/2;
 return{x:Math.min(1,Math.max(0,(cx-l)/w)),y:Math.min(1,Math.max(0,(cy-t)/h))}};
const queueMove=p=>{pend=p;if(!raf)raf=requestAnimationFrame(()=>{raf=0;if(pend){send({t:'move',...pend});pend=null}})};
v.addEventListener('touchstart',e=>{e.preventDefault();$('#panel').hidden=true;clearTimeout(lp);
 if(e.touches.length===2){st={scroll:true,y:(e.touches[0].clientY+e.touches[1].clientY)/2,acc:0};return}
 if(e.touches.length!==1)return;
 const t=e.touches[0];st={x0:t.clientX,y0:t.clientY,drag:false,right:false};
 send({t:'move',...pct(t.clientX,t.clientY)});
 lp=setTimeout(()=>{if(st&&!st.drag&&!st.scroll){st.right=true;send({t:'click',b:'r',...pct(st.x0,st.y0)});navigator.vibrate?.(30)}},500);
},{passive:false});
v.addEventListener('touchmove',e=>{e.preventDefault();if(!st)return;
 if(st.scroll){if(e.touches.length===2){const y=(e.touches[0].clientY+e.touches[1].clientY)/2;st.acc+=(y-st.y)/12;st.y=y;const k=Math.trunc(st.acc);if(k){send({t:'wheel',dy:k});st.acc-=k}}return}
 if(e.touches.length!==1)return;
 const t=e.touches[0];
 if(!st.drag){if(Math.hypot(t.clientX-st.x0,t.clientY-st.y0)<8||st.right)return;st.drag=true;clearTimeout(lp);send({t:'down',b:'l',...pct(st.x0,st.y0)})}
 queueMove(pct(t.clientX,t.clientY));
},{passive:false});
v.addEventListener('touchend',e=>{e.preventDefault();clearTimeout(lp);if(!st||e.touches.length)return;
 if(st.drag){if(pend){send({t:'move',...pend});pend=null}send({t:'up',b:'l'})}
 else if(!st.right&&!st.scroll){const t=e.changedTouches[0];send({t:'click',b:'l',...pct(t.clientX,t.clientY)})}
 st=null},{passive:false});
v.addEventListener('touchcancel',()=>{clearTimeout(lp);if(st&&st.drag)send({t:'up',b:'l'});st=null});

/* Menu */
$('#menu').onclick=()=>{$('#panel').hidden=!$('#panel').hidden};
$('#fs').onclick=()=>{$('#panel').hidden=true;fullscreen()};
$('#bye').onclick=()=>location.reload();
$('#stat').onclick=()=>{$('#panel').hidden=true;const h=$('#hud');h.hidden=!h.hidden;clearInterval(statT);
 if(!h.hidden)statT=setInterval(async()=>{try{let fps='?',rtt='?';(await pc.getStats()).forEach(r=>{
  if(r.type==='inbound-rtp'&&r.kind==='video')fps=Math.round(r.framesPerSecond||0);
  if(r.type==='candidate-pair'&&r.nominated&&r.state==='succeeded')rtt=Math.round((r.currentRoundTripTime||0)*1000)});
  h.textContent=fps+' FPS · ping '+rtt+' ms'}catch(e){}},1000)};
