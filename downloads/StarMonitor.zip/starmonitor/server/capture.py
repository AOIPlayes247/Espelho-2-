"""Captura de um monitor específico (padrão: o monitor secundário)."""
import mss
import numpy as np


def list_monitors():
    with mss.mss() as sct:
        return [dict(m) for m in sct.monitors[1:]]  # índice 0 = todos os monitores juntos


def pick_monitor(arg="auto"):
    mons = list_monitors()
    if not mons:
        raise SystemExit("Nenhum monitor encontrado.")
    if arg != "auto":
        i = int(arg)
        if not 1 <= i <= len(mons):
            raise SystemExit(f"Monitor {arg} não existe. Use --list para ver os monitores.")
        return i, mons[i - 1]
    for i, m in enumerate(mons, 1):
        if (m["left"], m["top"]) != (0, 0):  # o monitor principal fica em (0, 0)
            return i, m
    raise SystemExit("Só existe um monitor. Ative o Virtual Display Driver e estenda a área de trabalho para ele.")


class MssCapture:
    """Captura por GDI/BitBlt (mss). Robusto, funciona com qualquer monitor."""

    def __init__(self, mon):
        self.mon = {k: mon[k] for k in ("left", "top", "width", "height")}
        self._sct = None  # o mss precisa ser criado e usado sempre na mesma thread

    def grab(self):
        if self._sct is None:
            self._sct = mss.mss()
        return np.asarray(self._sct.grab(self.mon))  # BGRA

    def close(self):
        pass


class DxCapture:
    """Captura por DXGI Desktop Duplication (dxcam). Mais rápido; requer --dx-device/--dx-output corretos."""

    def __init__(self, fps, device, output):
        import dxcam
        self.cam = dxcam.create(device_idx=device, output_idx=output, output_color="BGRA")
        self.cam.start(target_fps=fps, video_mode=True)
        self._last = None
        while self._last is None:
            self._last = self.cam.get_latest_frame()

    def grab(self):
        f = self.cam.get_latest_frame()
        if f is not None:
            self._last = f
        return self._last

    def close(self):
        try:
            self.cam.stop()
        except Exception:
            pass


def make_capture(backend, mon, fps, dx_device, dx_output):
    if backend == "dxcam":
        return DxCapture(fps, dx_device, dx_output)
    return MssCapture(mon)
