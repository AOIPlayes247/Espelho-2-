"""Converte eventos de toque em mouse real, restrito ao monitor capturado."""
import ctypes
import sys
import time

if sys.platform != "win32":
    raise SystemExit("O StarMonitor funciona somente no Windows.")

user32 = ctypes.windll.user32
user32.SetProcessDPIAware()
user32.mouse_event.argtypes = [ctypes.c_ulong] * 4 + [ctypes.c_size_t]
FLAGS = {("l", True): 0x0002, ("l", False): 0x0004, ("r", True): 0x0008, ("r", False): 0x0010}
WHEEL = 0x0800


class Mouse:
    def __init__(self, mon):
        self.m = mon

    def move(self, d):
        x = min(max(float(d["x"]), 0.0), 1.0)
        y = min(max(float(d["y"]), 0.0), 1.0)
        user32.SetCursorPos(int(self.m["left"] + x * (self.m["width"] - 1)),
                            int(self.m["top"] + y * (self.m["height"] - 1)))

    @staticmethod
    def button(b, down):
        user32.mouse_event(FLAGS[("r" if b == "r" else "l", down)], 0, 0, 0, 0)

    def handle(self, d):
        t = d.get("t")
        b = d.get("b")
        if t == "move":
            self.move(d)
        elif t == "down":
            if "x" in d:
                self.move(d)
            self.button(b, True)
        elif t == "up":
            self.button(b, False)
        elif t == "click":
            if "x" in d:
                self.move(d)
            self.button(b, True)
            time.sleep(0.012)
            self.button(b, False)
        elif t == "wheel":
            notches = int(max(-10, min(10, float(d["dy"]))))
            user32.mouse_event(WHEEL, 0, 0, (notches * 120) & 0xFFFFFFFF, 0)
