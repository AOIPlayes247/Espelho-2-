"""StarMonitor - servidor: captura o monitor secundário e envia por WebRTC (somente rede local)."""
import argparse
import asyncio
import hmac
import ipaddress
import json
import secrets
import socket
import ssl
import time
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction
from pathlib import Path

import av
import numpy as np
from aiohttp import web
from aiortc import RTCConfiguration, RTCPeerConnection, RTCRtpSender, RTCSessionDescription, VideoStreamTrack

from capture import list_monitors, make_capture, pick_monitor
from inputctl import Mouse

CLIENT = Path(__file__).resolve().parent.parent / "client"
PIN = ""
ARGS = None
MON = None
MOUSE = None
S = {"token": None, "pc": None, "ws": None, "track": None, "fails": {}, "lock": {}}


class ScreenTrack(VideoStreamTrack):
    """Faixa de vídeo: captura -> yuv420p -> WebRTC, ritmada em --fps."""
    kind = "video"

    def __init__(self, cap, fps, max_w):
        super().__init__()
        self.cap, self.fps, self.max_w = cap, fps, max_w
        self.pool = ThreadPoolExecutor(1)  # captura e conversão fora do loop asyncio
        self._t0 = self._next = None

    def _make(self):
        f = av.VideoFrame.from_ndarray(np.ascontiguousarray(self.cap.grab()), format="bgra")
        w, h = f.width, f.height
        if self.max_w and w > self.max_w:
            h, w = int(h * self.max_w / w), self.max_w
        return f.reformat(width=w // 2 * 2, height=h // 2 * 2, format="yuv420p")

    async def recv(self):
        now = time.perf_counter()
        if self._t0 is None:
            self._t0 = self._next = now
        if self._next > now:
            await asyncio.sleep(self._next - now)
        self._next = max(self._next + 1 / self.fps, time.perf_counter())  # sem rajadas de recuperação
        frame = await asyncio.get_running_loop().run_in_executor(self.pool, self._make)
        frame.pts = int((time.perf_counter() - self._t0) * 90000)
        frame.time_base = Fraction(1, 90000)
        return frame

    def stop(self):
        super().stop()
        self.pool.shutdown(wait=False)
        try:
            self.cap.close()
        except Exception:
            pass


async def close_session():
    S["token"] = None
    ws, pc, tr = S["ws"], S["pc"], S["track"]
    S["ws"] = S["pc"] = S["track"] = None
    if ws is not None and not ws.closed:
        await ws.close()
    if tr is not None:
        tr.stop()
    if pc is not None:
        await pc.close()


@web.middleware
async def guard(request, handler):
    """Somente rede local: recusa qualquer IP que não seja privado/loopback/link-local."""
    try:
        ip = ipaddress.ip_address(request.remote)
    except ValueError:
        raise web.HTTPForbidden()
    if ip.version == 6 and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    if not (ip.is_private or ip.is_loopback or ip.is_link_local):
        raise web.HTTPForbidden(text="Somente rede local.")
    resp = await handler(request)
    resp.headers.update({"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY",
                         "Referrer-Policy": "no-referrer", "Cache-Control": "no-store"})
    return resp


def authed(request):
    tok = request.headers.get("Authorization", "").removeprefix("Bearer ") or request.query.get("t", "")
    return bool(S["token"]) and hmac.compare_digest(tok.encode(), S["token"].encode())


async def login(request):
    ip, now = request.remote, time.time()
    if S["lock"].get(ip, 0) > now:
        return web.json_response({"error": "Muitas tentativas. Aguarde 1 minuto."}, status=429)
    try:
        pin = str((await request.json()).get("pin", ""))
    except Exception:
        return web.json_response({"error": "Requisição inválida"}, status=400)
    if not hmac.compare_digest(pin.encode(), PIN.encode()):
        S["fails"][ip] = S["fails"].get(ip, 0) + 1
        if S["fails"][ip] >= 5:
            S["lock"][ip], S["fails"][ip] = now + 60, 0
        await asyncio.sleep(1)
        return web.json_response({"error": "PIN incorreto"}, status=401)
    S["fails"].pop(ip, None)
    await close_session()  # uma sessão por vez
    S["token"] = secrets.token_urlsafe(24)
    return web.json_response({"token": S["token"], "w": MON["width"], "h": MON["height"]})


async def offer(request):
    if not authed(request):
        raise web.HTTPUnauthorized()
    try:
        p = await request.json()
        sdp, typ = p["sdp"], p["type"]
    except Exception:
        raise web.HTTPBadRequest()
    old_token = S["token"]
    await close_session()
    S["token"] = old_token  # mantém o token; só a mídia anterior é encerrada
    pc = RTCPeerConnection(RTCConfiguration(iceServers=[]))  # sem STUN/TURN: só candidatos da LAN
    try:
        track = ScreenTrack(make_capture(ARGS.backend, MON, ARGS.fps, ARGS.dx_device, ARGS.dx_output),
                            ARGS.fps, ARGS.max_width)
    except Exception as e:
        await pc.close()
        return web.json_response({"error": f"Falha na captura: {e}"}, status=500)
    sender = pc.addTrack(track)
    S["pc"], S["track"] = pc, track
    prefs = [c for c in RTCRtpSender.getCapabilities("video").codecs if c.mimeType.lower() == "video/" + ARGS.codec]
    if prefs:
        next(t for t in pc.getTransceivers() if t.sender == sender).setCodecPreferences(prefs)

    @pc.on("connectionstatechange")
    async def _state():
        if pc.connectionState in ("failed", "closed") and S["pc"] is pc:
            await close_session()

    await pc.setRemoteDescription(RTCSessionDescription(sdp=sdp, type=typ))
    await pc.setLocalDescription(await pc.createAnswer())
    return web.json_response({"sdp": pc.localDescription.sdp, "type": pc.localDescription.type})


async def ws_handler(request):
    if not authed(request):
        raise web.HTTPUnauthorized()
    ws = web.WebSocketResponse(max_msg_size=2048, heartbeat=15)
    await ws.prepare(request)
    old, S["ws"] = S["ws"], ws
    if old is not None and not old.closed:
        await old.close()
    start, count = time.time(), 0
    async for msg in ws:
        if msg.type != web.WSMsgType.TEXT:
            continue
        t = time.time()
        if t - start > 1:
            start, count = t, 0
        count += 1
        if count > 400:  # limite de eventos por segundo
            continue
        try:
            MOUSE.handle(json.loads(msg.data))
        except Exception as e:
            print("erro:", e)
    if S["ws"] is ws:
        await close_session()
    return ws


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))  # não envia nada; só descobre a interface de saída
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()


def tune_bitrate(mbps):
    from aiortc.codecs import h264, vpx
    mx = int(mbps * 1_000_000)
    for mod in (h264, vpx):
        for name, val in (("MAX_BITRATE", mx), ("DEFAULT_BITRATE", mx // 2), ("MIN_BITRATE", mx // 8)):
            if hasattr(mod, name):
                setattr(mod, name, val)


def main():
    global PIN, ARGS, MON, MOUSE
    ap = argparse.ArgumentParser(description="StarMonitor: celular como segundo monitor (somente rede local)")
    ap.add_argument("--list", action="store_true", help="lista os monitores e sai")
    ap.add_argument("--monitor", default="auto", help="número do monitor (veja --list); padrão: o primeiro que não é o principal")
    ap.add_argument("--host", default="0.0.0.0", help="endereço de escuta (padrão: todas as interfaces)")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--fps", type=int, default=30, help="quadros por segundo (padrão 30)")
    ap.add_argument("--max-width", type=int, default=1920, help="largura máxima enviada (reduz a carga de CPU)")
    ap.add_argument("--bitrate", type=float, default=12, help="taxa máxima em Mbps (padrão 12)")
    ap.add_argument("--codec", choices=["h264", "vp8"], default="h264")
    ap.add_argument("--backend", choices=["mss", "dxcam"], default="mss")
    ap.add_argument("--dx-device", type=int, default=0)
    ap.add_argument("--dx-output", type=int, default=1)
    ap.add_argument("--pin", help="PIN de 6 dígitos (padrão: aleatório a cada execução)")
    ap.add_argument("--cert", help="certificado TLS (.pem) para servir em HTTPS")
    ap.add_argument("--key", help="chave privada TLS (.pem)")
    ARGS = ap.parse_args()
    if ARGS.list:
        for i, m in enumerate(list_monitors(), 1):
            print(f"{i}: {m['width']}x{m['height']} em ({m['left']}, {m['top']})")
        return
    idx, MON = pick_monitor(ARGS.monitor)
    MOUSE = Mouse(MON)
    PIN = ARGS.pin or f"{secrets.randbelow(10 ** 6):06d}"
    tune_bitrate(ARGS.bitrate)
    app = web.Application(middlewares=[guard])
    app.router.add_get("/", lambda r: web.FileResponse(CLIENT / "index.html"))
    app.router.add_post("/api/login", login)
    app.router.add_post("/api/offer", offer)
    app.router.add_get("/ws", ws_handler)
    app.router.add_static("/", CLIENT)
    ctx = None
    if ARGS.cert and ARGS.key:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(ARGS.cert, ARGS.key)
    url = f"{'https' if ctx else 'http'}://{lan_ip()}:{ARGS.port}"
    print(f"\nMonitor capturado: {idx} ({MON['width']}x{MON['height']})")
    print(f"Abra no celular (mesmo Wi-Fi): {url}")
    print(f"PIN: {PIN}\nCtrl+C para encerrar.\n")
    web.run_app(app, host=ARGS.host, port=ARGS.port, ssl_context=ctx, print=None)


if __name__ == "__main__":
    main()
