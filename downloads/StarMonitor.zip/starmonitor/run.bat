@echo off
chcp 65001 >nul
title StarMonitor
cd /d "%~dp0"
where py >nul 2>nul || (echo Python nao encontrado. Instale em https://www.python.org/downloads/ marcando "Add Python to PATH". & pause & exit /b 1)
if not exist .venv (py -m venv .venv)
call .venv\Scripts\activate
pip install -r requirements.txt
python server\main.py %*
pause
