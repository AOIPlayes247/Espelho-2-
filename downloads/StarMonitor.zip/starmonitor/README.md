# StarMonitor

Use o **celular como segundo monitor** do PC Windows, **somente na rede local (Wi-Fi/LAN)**. Projeto open-source no estilo spacedesk.

- **Monitor virtual:** criado por um driver existente (Virtual Display Driver). Este projeto cuida só da captura, da transmissão e do toque.
- **Servidor (PC):** Python. Captura **apenas o monitor secundário**, codifica em H.264 (ou VP8) e envia por **WebRTC sem STUN/TURN**.
- **Cliente (celular):** página web servida pelo próprio PC, instalável como PWA. O toque vira mouse **na segunda tela**.

## Como funciona

```
Celular (navegador)  <-- WebRTC (vídeo, UDP, só LAN) --  Servidor Python  <-- captura do monitor virtual
        |                                                     ^
        +----- WebSocket (toques: mover, clicar, rolar) ------+  -> mouse do Windows, limitado ao monitor secundário
```

## Pré-requisitos

- Windows 10/11 e **Python 3.10 a 3.12** (marque "Add Python to PATH" ao instalar).
- PC e celular no **mesmo Wi-Fi/rede** (sem VPN e sem rede de visitantes com isolamento de clientes).
- Um monitor virtual instalado (veja abaixo) ou um segundo monitor físico.

## Instalar o driver do monitor virtual

1. Abra https://github.com/VirtualDrivers/Virtual-Display-Driver e vá em **Releases**.
2. Baixe o **Virtual Driver Control (VDC)**, extraia, abra e clique em **Install**.
3. Confira em **Gerenciador de Dispositivos → Adaptadores de vídeo** se o driver aparece.
4. Em **Configurações → Sistema → Tela**, escolha **Estender estas telas** e ajuste a resolução do monitor virtual (por exemplo, a proporção do seu celular).

Atenção: antes de atualizar o driver da placa de vídeo, desinstale o driver virtual. O projeto dele avisa que a atualização pode causar tela preta. Siga as instruções oficiais do repositório dele.

## Instalação do StarMonitor

```bash
git clone https://github.com/SEU-USUARIO/starmonitor.git
cd starmonitor
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

Ou dê dois cliques em `run.bat`, que faz tudo isso e inicia o servidor.

## Usar

```bash
python server\main.py
```

O programa mostra o endereço e o PIN, por exemplo:

```
Monitor capturado: 2 (1920x1080)
Abra no celular (mesmo Wi-Fi): http://192.168.0.10:8080
PIN: 482913
```

1. No celular, abra o endereço no Chrome.
2. Digite o PIN e toque em **Conectar**. A tela do monitor secundário aparece em tela cheia.
3. Arraste janelas do Windows para o monitor virtual e use o toque:
   - **Tocar:** clique esquerdo.
   - **Arrastar:** mantém o botão esquerdo pressionado e move (arrastar janelas e selecionar).
   - **Segurar 0,5 s:** clique direito.
   - **Dois dedos:** rolar.

### Opções

| Opção | Descrição |
|---|---|
| `--list` | Lista os monitores e sai |
| `--monitor N` | Escolhe o monitor (padrão: o primeiro que não é o principal) |
| `--fps 30` | Quadros por segundo (suba para 60 se o PC aguentar) |
| `--max-width 1920` | Largura máxima enviada (reduza para 1280 em PCs fracos) |
| `--bitrate 12` | Taxa máxima em Mbps |
| `--codec h264` ou `vp8` | Codec (use `vp8` se o vídeo não aparecer com h264) |
| `--backend mss` ou `dxcam` | Captura. `dxcam` é mais rápido (`pip install dxcam`, ajuste `--dx-device` e `--dx-output`) |
| `--port 8080` | Porta HTTP |
| `--pin 123456` | Define o PIN (padrão: aleatório a cada execução) |
| `--cert` e `--key` | Servir em HTTPS com seu certificado |

## Segurança (rede local)

- O servidor **recusa qualquer IP que não seja da rede local** (privado, loopback ou link-local).
- O WebRTC usa **só candidatos da LAN**, sem STUN/TURN.
- Acesso por **PIN** (6 dígitos, novo a cada execução), com bloqueio de 1 minuto após 5 erros e **uma sessão por vez**.
- Limite de tamanho e de quantidade de eventos de toque, e o mouse só se move **dentro do monitor capturado**.
- Não exponha a porta do servidor na internet (não faça redirecionamento de porta no roteador).
- O tráfego de vídeo do WebRTC é criptografado. A página e o login via HTTP simples não são. Em redes que você não controla, use HTTPS (`--cert` e `--key`).

## Instalar como PWA

Navegadores só instalam PWA em **HTTPS ou localhost**. Em `http://192.168.x.x` o Chrome do Android não oferece "Instalar app" por padrão. Escolha uma opção:

1. **Atalho e tela cheia:** abra o endereço no Chrome, menu ⋮ → **Adicionar à tela inicial**. O botão **⛶ Tela cheia** do menu ☰ cobre o resto.
2. **Liberar o endereço no Chrome:** em `chrome://flags/#unsafely-treat-insecure-origin-as-secure`, ative a opção e adicione `http://IP-DO-PC:8080`. Reinicie o Chrome e use ⋮ → **Instalar app**.
3. **HTTPS confiável:** gere um certificado com o mkcert, instale a CA no celular e inicie com `--cert` e `--key`.

## Solução de problemas

- **Não conecta:** confira o mesmo Wi-Fi, o firewall do Windows (permita o Python na rede privada) e se não há VPN. Algumas redes bloqueiam a conexão entre aparelhos.
- **"Só existe um monitor":** o driver virtual não está ativo ou a área de trabalho não foi estendida.
- **Tela preta ou sem vídeo:** teste `--codec vp8`, reduza `--max-width` e `--fps`.
- **Atraso ou travadas:** use Wi-Fi 5 GHz, reduza `--max-width`, tente `--backend dxcam`. A codificação é por software (CPU).
- **O toque cai no lugar errado:** use `--monitor` para escolher o monitor certo e confirme que o Windows está com a escala de tela correta.

## Limitações

- Somente Windows. Um celular por vez. Sem áudio. O toque simula só o mouse (sem multitoque além da rolagem).
- A codificação roda na CPU (aiortc), então o desempenho varia conforme o PC. Não substitui um driver nativo como o do spacedesk.

## Estrutura

```
server/  main.py (HTTP, WebSocket, WebRTC)  capture.py (captura)  inputctl.py (mouse)
client/  index.html  app.js  style.css  manifest.json  sw.js  ícones
requirements.txt  run.bat  .gitignore  LICENSE  README.md
```

## Licença e créditos

MIT. Criado por **AOIofc1**: https://www.youtube.com/@AOIofc1
